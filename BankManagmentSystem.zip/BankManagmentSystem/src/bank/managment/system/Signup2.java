package bank.managment.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Signup2 extends JFrame implements ActionListener {

    String formno;

    JComboBox comboBox,comboBox2,comboBox3,comboBox4,comboBox5;
    JTextField textpan,textadhar;
    JRadioButton r1,r2,e1,e2;
    JButton next;

    Signup2(String first){

        super("APPLICATION FORM");

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icon/bank.png"));
        Image i2 = i1.getImage().getScaledInstance(100,100,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(30,30,100,100);
        add(image);

        this.formno = first;

        JLabel l1 = new JLabel(" Page 2 :- Additional Details ");
        l1.setFont(new Font("Ralway",Font.BOLD,22));
        l1.setBounds(300,60,600,40);
        add(l1);

        JLabel l2 = new JLabel(" Religion  : ");
        l2.setFont(new Font("Ralway",Font.BOLD,18));
        l2.setBounds(200,150,100,30);
        add(l2);

        String religion[] = {"Hindu","Muslim","Christian","Other"};
        comboBox = new JComboBox(religion);
        comboBox.setFont(new Font("Ralway",Font.BOLD,14));
        comboBox.setBackground(new Color(68, 181, 43));
        comboBox.setBounds(380,150,320,30);
        add(comboBox);

        JLabel l3 = new JLabel(" Category : ");
        l3.setFont(new Font("Ralway",Font.BOLD,18));
        l3.setBounds(200,210,120,30);
        add(l3);

        String category[] = {"General","OBC","SC","ST","NT"};
        comboBox2 = new JComboBox(category);
        comboBox2.setFont(new Font("Ralway",Font.BOLD,14));
        comboBox2.setBackground(new Color(68, 181, 43));
        comboBox2.setBounds(380,210,320,30);
        add(comboBox2);

        JLabel l4 = new JLabel(" Income  : ");
        l4.setFont(new Font("Ralway",Font.BOLD,18));
        l4.setBounds(200,270,120,30);
        add(l4);

        String income[] = {"Null","<1,50,000","<2,50,000","<5,00,000","UPTO 10,00,000","ABOVE 10,00,000"};
        comboBox3 = new JComboBox(income);
        comboBox3.setFont(new Font("Ralway",Font.BOLD,14));
        comboBox3.setBackground(new Color(68, 181, 43));
        comboBox3.setBounds(380,270,320,30);
        add(comboBox3);

        JLabel l5 = new JLabel(" Education : ");
        l5.setFont(new Font("Ralway",Font.BOLD,18));
        l5.setBounds(200,330,120,30);
        add(l5);

        String education[] = {"Non-Graduate","Graduate","Post-Graduate","PHD"};
        comboBox4 = new JComboBox(education);
        comboBox4.setFont(new Font("Ralway",Font.BOLD,14));
        comboBox4.setBackground(new Color(68, 181, 43));
        comboBox4.setBounds(380,330,320,30);
        add(comboBox4);

        JLabel l6 = new JLabel(" Occupation: ");
        l6.setFont(new Font("Ralway",Font.BOLD,18));
        l6.setBounds(200,390,120,30);
        add(l6);

        String occupation[] = {"Salaried","Self-Employed","Bussiness","Student","Retired","Other"};
        comboBox5 = new JComboBox(occupation);
        comboBox5.setFont(new Font("Ralway",Font.BOLD,14));
        comboBox5.setBackground(new Color(68, 181, 43));
        comboBox5.setBounds(380,390,320,30);
        add(comboBox5);

        JLabel l7 = new JLabel(" PAN NO  : ");
        l7.setFont(new Font("Ralway",Font.BOLD,18));
        l7.setBounds(200,450,120,30);
        add(l7);

        textpan = new JTextField();
        textpan.setFont(new Font("Ralway",Font.BOLD,18));
        textpan.setBounds(380,450,320,30);
        add(textpan);

        JLabel l8 = new JLabel(" ADHAR NO : ");
        l8.setFont(new Font("Ralway",Font.BOLD,18));
        l8.setBounds(200,510,150,30);
        add(l8);

        textadhar = new JTextField();
        textadhar.setFont(new Font("Ralway",Font.BOLD,18));
        textadhar.setBounds(380,510,320,30);
        add(textadhar);

        JLabel l9 = new JLabel(" Senior Citizen : ");
        l9.setFont(new Font("Ralway",Font.BOLD,18));
        l9.setBounds(200,570,150,30);
        add(l9);

        r1 = new JRadioButton("YES");
        r1.setFont(new Font("Ralway",Font.BOLD,14));
        r1.setBackground(new Color(146,172,169));
        r1.setBounds(380,570,100,30);
        add(r1);

        r2 = new JRadioButton("NO");
        r2.setFont(new Font("Ralway",Font.BOLD,14));
        r2.setBackground(new Color(146,172,169));
        r2.setBounds(480,570,100,30);
        add(r2);

        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(r1);
        buttonGroup.add(r2);

        JLabel l10 = new JLabel(" Existing Account : ");
        l10.setFont(new Font("Ralway",Font.BOLD,18));
        l10.setBounds(200,630,200,30);
        add(l10);

        e1 = new JRadioButton("YES");
        e1.setFont(new Font("Ralway",Font.BOLD,14));
        e1.setBackground(new Color(146,172,169));
        e1.setBounds(380,630,100,30);
        add(e1);

        e2 = new JRadioButton("NO");
        e2.setFont(new Font("Ralway",Font.BOLD,14));
        e2.setBackground(new Color(146,172,169));
        e2.setBounds(480,630,100,30);
        add(e2);

        ButtonGroup buttonGroup2 = new ButtonGroup();
        buttonGroup.add(e1);
        buttonGroup.add(e2);

        JLabel l11 = new JLabel(" Form NO : ");
        l11.setFont(new Font("Ralway",Font.BOLD,18));
        l11.setBounds(600,10,100,30);
        add(l11);

        JLabel l12 = new JLabel(formno);
        l12.setFont(new Font("Ralway",Font.BOLD,18));
        l12.setBounds(760,10,60,30);
        add(l12);

        next = new JButton("Next");
        next.setBounds(400,700,100,30);
        next.setBackground(Color.BLACK);
        next.setFont(new Font("Ralway",Font.BOLD,14));
        next.setForeground(Color.WHITE);
        next.addActionListener(this);
        add(next);





        setLayout(null);
        getContentPane().setBackground(new Color(146, 172, 169));
        setSize(850,800);
        setLocation(360,20);
        setUndecorated(true);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String rel = (String)comboBox.getSelectedItem();
        String cat = (String)comboBox2.getSelectedItem();
        String inc = (String)comboBox3.getSelectedItem();
        String edu = (String)comboBox4.getSelectedItem();
        String occ = (String)comboBox5.getSelectedItem();

        String pan = (String)textpan.getText();
        String aadhar = (String)textadhar.getText();

        String citizen = " ";
        if(r1.isSelected()){
            citizen = "YES";
        }else if(r2.isSelected()){
            citizen = "NO";
        }

        String account = " ";
        if(e1.isSelected()){
            account = "YES";
        }else if(e2.isSelected()){
            account = "NO";
        }

        try{
            if(textpan.getText().equals("") || textadhar.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Fill All The Fields");
            }else{
                Con con = new Con();
                String q = "insert into signup2 values('"+formno+"','"+rel+"','"+cat+"','"+inc+"','"+edu+"','"+occ+"','"+pan+"','"+aadhar+"','"+citizen+"','"+account+"')";
                con.statement.executeUpdate(q);
                new Signup3(formno);
                setVisible(false);
            }
        }catch(Exception E){
            E.printStackTrace();
        }
    }
    public static void main(String[] args) {
      new Signup2("");
    }
}
