package bank.managment.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Signup3 extends JFrame implements ActionListener {

    String formno;

    JRadioButton r1,r2,r3,r4;
    JCheckBox c1,c2,c3,c4,c5,c6,c7;
    JButton s,c;

    Signup3(String formno){

        super("APPLICATION FORM");

        this.formno = formno;

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icon/bank.png"));
        Image i2 = i1.getImage().getScaledInstance(100,100,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(30,30,100,100);
        add(image);

        JLabel l1 = new JLabel(" Page 3 : Account Details ");
        l1.setBounds(300,50,400,40);
        l1.setFont(new Font("Railway",Font.BOLD,18));
        add(l1);

        JLabel l2 = new JLabel(" Account Type : ");
        l2.setBounds(150,160,400,30);
        l2.setFont(new Font("Railway",Font.BOLD,20));
        add(l2);

        r1 = new JRadioButton(" Saving Account ");
        r1.setFont(new Font("Ralway",Font.BOLD,16));
        r1.setBounds(150,200,200,40);
        r1.setBackground(new Color(146, 172, 169));
        add(r1);

        r2 = new JRadioButton(" Fixed Deposit Account ");
        r2.setFont(new Font("Ralway",Font.BOLD,16));
        r2.setBounds(350,200,300,40);
        r2.setBackground(new Color(146, 172, 169));
        add(r2);

        r3 = new JRadioButton(" Current Account");
        r3.setFont(new Font("Ralway",Font.BOLD,16));
        r3.setBounds(150,250,200,40);
        r3.setBackground(new Color(146, 172, 169));
        add(r3);

        r4 = new JRadioButton(" Recurring Deposite Account ");
        r4.setFont(new Font("Ralway",Font.BOLD,16));
        r4.setBounds(350,250,300,40);
        r4.setBackground(new Color(146, 172, 169));
        add(r4);

        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(r1);
        buttonGroup.add(r2);
        buttonGroup.add(r3);
        buttonGroup.add(r4);

        JLabel l3 = new JLabel(" Card Number  : ");
        l3.setBounds(150,300,400,30);
        l3.setFont(new Font("Railway",Font.BOLD,18));
        add(l3);

        JLabel l4 = new JLabel("(Your 16 Digit card No.) ");
        l4.setBounds(150,320,400,40);
        l4.setFont(new Font("Railway",Font.BOLD,12));
        add(l4);

        JLabel l5 = new JLabel(" XXXX-XXXX-XXXX-4865 ");
        l5.setBounds(350,300,400,30);
        l5.setFont(new Font("Railway",Font.BOLD,18));
        add(l5);

        JLabel l6 = new JLabel(" (It would appear on atm card/chqeue book and statement) ");
        l6.setBounds(350,320,400,30);
        l6.setFont(new Font("Railway",Font.BOLD,12));
        add(l6);

        JLabel l7 = new JLabel(" PIN  : ");
        l7.setBounds(150,370,400,30);
        l7.setFont(new Font("Railway",Font.BOLD,18));
        add(l7);

        JLabel l8 = new JLabel(" XXXX ");
        l8.setBounds(350,370,400,30);
        l8.setFont(new Font("Railway",Font.BOLD,18));
        add(l8);

        JLabel l9 = new JLabel(" ( Your Four Digit Password) ");
        l9.setBounds(150,390,400,30);
        l9.setFont(new Font("Railway",Font.BOLD,12));
        add(l9);

        JLabel l10 = new JLabel(" Services Required : ");
        l10.setBounds(150,440,400,30);
        l10.setFont(new Font("Railway",Font.BOLD,18));
        add(l10);

        c1 = new JCheckBox(" ATM Card ");
        c1.setBackground(new Color(146,172,169));
        c1.setFont(new Font("Railway",Font.BOLD,14));
        c1.setBounds(150,490,300,30);
        add(c1);

        c2 = new JCheckBox(" Internet Banking ");
        c2.setBackground(new Color(146,172,169));
        c2.setFont(new Font("Railway",Font.BOLD,14));
        c2.setBounds(500,490,300,30);
        add(c2);

        c3 = new JCheckBox(" Mobile Banking ");
        c3.setBackground(new Color(146,172,169));
        c3.setFont(new Font("Railway",Font.BOLD,14));
        c3.setBounds(150,540,300,30);
        add(c3);

        c4 = new JCheckBox(" Email Alert ");
        c4.setBackground(new Color(146,172,169));
        c4.setFont(new Font("Railway",Font.BOLD,14));
        c4.setBounds(500,540,300,30);
        add(c4);

        c5 = new JCheckBox(" Cheque Book ");
        c5.setBackground(new Color(146,172,169));
        c5.setFont(new Font("Railway",Font.BOLD,14));
        c5.setBounds(150,590,300,30);
        add(c5);

        c6 = new JCheckBox(" E-Statement ");
        c6.setBackground(new Color(146,172,169));
        c6.setFont(new Font("Railway",Font.BOLD,14));
        c6.setBounds(500,590,300,30);
        add(c6);

        c7 = new JCheckBox("I here by declares that the above entered detailes correct to the best of my knowledge ",true);
        c7.setBackground(new Color(146,172,169));
        c7.setFont(new Font("Railway",Font.BOLD,14));
        c7.setBounds(150,640,800,30);
        add(c7);

        JLabel l11 = new JLabel(" Form No. : ");
        l11.setFont(new Font("Railway",Font.BOLD,18));
        l11.setBounds(600,10,100,30);
        add(l11);

        JLabel l12 = new JLabel(formno);
        l12.setFont(new Font("Railway",Font.BOLD,18));
        l12.setBounds(740,10,100,30);
        add(l12);

        s = new JButton(" Submit ");
        s.setFont(new Font("Railway",Font.BOLD,16));
        s.setBackground(Color.BLACK);
        s.setForeground(Color.WHITE);
        s.setBounds(250,690,100,30);
        s.addActionListener(this);
        add(s);

        c = new JButton(" Cancel ");
        c.setFont(new Font("Railway",Font.BOLD,16));
        c.setBackground(Color.BLACK);
        c.setForeground(Color.WHITE);
        c.setBounds(450,690,100,30);
        c.addActionListener(this);
        add(c);

        setLayout(null);
        getContentPane().setBackground(new Color(146, 172, 169));
        setSize(850,800);
        setLocation(360,20);
        setUndecorated(true);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String account = "";
        if(r1.isSelected()){
            account = "Saving Account";
        }else if(r2.isSelected()){
            account = "Fixed Deposit Account";
        }else if(r3.isSelected()){
            account = "Current Account";
        }else if(r4.isSelected()){
            account = "Recurring Deposite Account";
        }

        Random ran = new Random();
        long first7 = (ran.nextLong() % 90000000L ) + 1409963000000000L ;
        String card_no = ""+Math.abs(first7);

        long first3 = (ran.nextLong() % 9000L ) + 1000L;
        String pin = ""+Math.abs(first3);

        String fac = " ";
        if(c1.isSelected()){
            fac = fac + "ATM CARD";
        }else if(c2.isSelected()){
            fac = fac + "Internet  Banking";
        }else if(c3.isSelected()){
            fac = fac + "Mobile Banking";
        }else if(c4.isSelected()){
            fac = fac + "Email Alert";
        }else if(c5.isSelected()){
            fac = fac + "Cheque Book";
        }else if(c6.isSelected()){
            fac = fac + "E-Statement";
        }

        try{
            if(e.getSource()==s){
                if(account.equals("")){
                    JOptionPane.showMessageDialog(null,"Fill All The Field");
                }else{
                    Con con = new Con();
                    String q1 = "insert into signup3 values('"+formno+"','"+account+"','"+card_no+"','"+pin+"','"+fac+"')";
                    String q2 = "insert into login values('"+formno+"','"+card_no+"','"+pin+"')";
                    con.statement.executeUpdate(q1);
                    con.statement.executeUpdate(q2);
                    JOptionPane.showMessageDialog(null,"Card Number : "+card_no+" Pin Number : "+pin);
                    new Deposite(pin);
                    setVisible(false);
                }

            }else if(e.getSource()==c){
                System.exit(0);
            }

        }catch(Exception E){
            E.printStackTrace();
        }


    }

    public static void main(String[] args) {
        new Signup3("");
    }

}
