package bank.managment.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

public class Deposite extends JFrame implements ActionListener {

    String pin;

    JTextField textField;
    JButton b1,b2;

    Deposite(String pin){

        super(" ATM ");

        this.pin = pin;



        JLabel l1 = new JLabel(" ENTER AMOUNT YOU WANT TO DEPOSITE ");
        l1.setFont(new Font("Railway",Font.BOLD,16));
        l1.setBounds(460,180,400,35);
        l1.setForeground(Color.WHITE);
        add(l1);

        textField = new JTextField();
        textField.setBounds(470,230,320,25);
        textField.setFont(new Font("Railway",Font.BOLD,20));
        textField.setBackground(new Color(65,125,128));
        textField.setForeground(Color.WHITE);
        add(textField);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icon/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1550,830,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0,1550,780);
        add(image);

        b1 = new JButton(" DEPOSITE ");
        b1.setBounds(700,340,150,35);
        b1.setBackground(new Color(65,125,128));
        b1.setForeground(Color.WHITE);
        b1.addActionListener(this);
        image.add(b1);

        b2 = new JButton(" BACK ");
        b2.setBounds(700,390,150,35);
        b2.setBackground(new Color(65,125,128));
        b2.setForeground(Color.WHITE);
        b2.addActionListener(this);
        image.add(b2);

        setSize(1550,830);
        setLocation(0,0);
        setLayout(null);
        setUndecorated(true);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try{

              String amount = textField.getText();
              Date date = new Date();
              if(e.getSource()==b1){
                  if(textField.getText().equals("")){
                      JOptionPane.showMessageDialog(null," PLEASE ENTER AMOUNT YOU WANT TO DEPOSITE ");
                  }else{
                      Con con = new Con();
                      String q = "insert into bank values('"+pin+"','"+date+"','Deposite','"+amount+"')";
                      con.statement.executeUpdate(q);
                      JOptionPane.showMessageDialog(null,"Rs "+amount+" Deposite Successfully ");
                      setVisible(false);
                      new main_class(pin);
                  }
              }else if(e.getSource()==b2){
                  setVisible(false);
                  new main_class(pin);
              }

        }catch(Exception E){
            E.printStackTrace();
        }

    }

    public static void main(String[] args) {

        new Deposite("");

    }
}
