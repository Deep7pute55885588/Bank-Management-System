package bank.managment.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import javax.xml.transform.Result;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Mini extends JFrame implements ActionListener {

    String pin;
    JButton button,print;
    JLabel label1,label2,label3,label4;


    Mini(String pin){

        super(" Mini Statement ");

        this.pin = pin;

       label1 = new JLabel();
        label1.setBounds(20,100,400,300);
        label1.setFont(new Font("System",Font.BOLD,12));
        add(label1);

        label2 = new JLabel(" SATPUTE BANK ");
        label2.setBounds(150,20,200,20);
        label2.setFont(new Font("System",Font.BOLD,15));
        add(label2);

        label3 = new JLabel();
        label3.setBounds(20,60,300,20);
        add(label3);

        label4 = new JLabel();
        label4.setBounds(20,600,300,20);
        add(label4);

        try{

            Con con = new Con();
            ResultSet resultset = con.statement.executeQuery("select * from login where pin = '"+pin+"'");
            while(resultset.next()){
                label3.setText("Card No : "+resultset.getString(2).substring(0,4)+"XXXXXXXX"+resultset.getString(2).substring(12));
            }

        }catch(Exception E){
            E.printStackTrace();
        }

        try{
            int balance = 0;
            Con con = new Con();
            ResultSet resultSet = con.statement.executeQuery("select * from bank where pin = '"+pin+"'");
            while (resultSet.next()){
               label1.setText(label1.getText()+"<html>"+resultSet.getString(2)+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+resultSet.getString(3)+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+resultSet.getString(4)+"<br><br><br><html>");






                if (resultSet.getString(3).equals("Deposite")){
                    balance += Integer.parseInt(resultSet.getString("amount"));
                }else {
                    balance -= Integer.parseInt(resultSet.getString("amount"));
                }
            }
            label4.setText("Your Total Balance In Rs. "+balance);
        }catch(Exception E){
            E.printStackTrace();
        }

        button = new JButton(" EXIT ");
        button.setBounds(20,650,100,25);
        button.setFont(new Font("Railway",Font.BOLD,16));
        button.setBackground(Color.BLACK);
        button.setForeground(Color.WHITE);
        button.addActionListener(this);
        add(button);

        print = new JButton(" Print ");
        print.setBounds(20,700,100,25);
        print.setFont(new Font("Railway",Font.BOLD,16));
        print.setBackground(Color.BLACK);
        print.setForeground(Color.WHITE);
        print.addActionListener(this);
        add(print);


        //print();
        setSize(500,750);
        setLocation(20,20);
        getContentPane().setBackground(new Color(255,204,204));
        setLayout(null);
        setUndecorated(true);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
          setVisible(false);

        }



    public static void main(String[] args) {
        new Mini("");

    }
}
