package bank.managment.system;

import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Signup extends JFrame implements ActionListener {

    Random ran = new Random();
    long first4 =(ran.nextLong() % 9000L) + 1000L;
    String first = ""+Math.abs(first4);


    JTextField textname,textfname,textemail,textms,textad,textcity,textpin,textstate;
    JDateChooser dateChooser;
    JRadioButton r1,r2,m1,m2,m3;
    JButton next;
    Signup(){
        super("Application Form");
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icon/bank.png"));
        Image i2 = i1.getImage().getScaledInstance(100,100,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(25,10,100,100);
        add(image);

        JLabel label1 = new JLabel("Application Form No : " + first4);
        label1.setBounds(220,20,600,40);
        label1.setFont(new Font("Raleway",Font.BOLD,38));
       // label1.setForeground(Color.WHITE);
        add(label1);

        JLabel label2 = new JLabel("Page 1");
        label2.setFont(new Font("Ralway",Font.BOLD,22));
        label2.setBounds(400,70,600,30);
        //label2.setForeground(Color.WHITE);
        add(label2);

        JLabel label3 = new JLabel("Personal Details");
        label3.setFont(new Font("Ralway",Font.BOLD,22));
        label3.setBounds(360,90,600,30);
      //  label3.setForeground(Color.WHITE);
        add(label3);

        JLabel labelname = new JLabel("Name  : ");
        labelname.setFont(new Font("Ralway",Font.BOLD,20));
        labelname.setBounds(150,190,600,30);
       // labelname.setForeground(Color.WHITE);
        add(labelname);

        textname = new JTextField();
        textname.setFont(new Font("Ralway",Font.BOLD,14));
        textname.setBounds(300,190,400,30);
        add(textname);

        JLabel labelfname = new JLabel("Father Name  : ");
        labelfname.setFont(new Font("Relway",Font.BOLD,20));
        labelfname.setBounds(150,230,600,30);
       // labelfname.setForeground(Color.WHITE);
        add(labelfname);

        textfname = new JTextField();
        textfname.setFont(new Font("Relway",Font.BOLD,14));
        textfname.setBounds(300,230,400,30);
        add(textfname);

        JLabel labelDob = new JLabel("Date Of Birth  : ");
        labelDob.setFont(new Font("Relway",Font.BOLD,20));
        labelDob.setBounds(150,270,600,30);
        //labelDob.setForeground(Color.WHITE);
        add(labelDob);

        dateChooser = new JDateChooser();
        dateChooser.setForeground(Color.WHITE);
        dateChooser.setBounds(300,270,400,30);
        dateChooser.setFont(new Font("Railway",Font.BOLD,14));
        add(dateChooser);

        JLabel labelgender = new JLabel("Gender  : ");
        labelgender.setFont(new Font("Railway",Font.BOLD,20));
        labelgender.setBounds(150,310,600,30);
      //  labelgender.setForeground(Color.WHITE);
        add(labelgender);

        r1 = new JRadioButton("Male ");
        r1.setFont(new Font("Raiway",Font.BOLD,16));
        r1.setBounds(300,310,100,30);
        r1.setBackground(new Color(222,255,228));
        add(r1);

        r2 = new JRadioButton("Female ");
        r2.setFont(new Font("Raiway",Font.BOLD,16));
        r2.setBounds(500,310,100,30);
        r2.setBackground(new Color(222,255,228));
        add(r2);

        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(r1);
        buttonGroup.add(r2);

        JLabel labelemail = new JLabel("Email   : ");
        labelemail.setFont(new Font("Railway",Font.BOLD,20));
        labelemail.setBounds(150,350,600,30);
        //labelemail.setForeground(Color.WHITE);
        add(labelemail);

        textemail = new JTextField();
        textemail.setFont(new Font("Ralway",Font.BOLD,14));
        textemail.setBounds(300,350,400,30);
        add(textemail);

        JLabel labelmarital = new JLabel("Marital Status  : ");
        labelmarital.setFont(new Font("Railway",Font.BOLD,20));
        labelmarital.setBounds(150,390,600,30);
      //  labelmarital.setForeground(Color.WHITE);
        add(labelmarital);

        m1 = new JRadioButton("Married ");
        m1.setFont(new Font("Ralway",Font.BOLD,14));
        m1.setBounds(300,390,100,30);
        m1.setBackground(new Color(222,255,228));
        m1.setForeground(Color.WHITE);
        add(m1);

        m2 = new JRadioButton("UnMarried ");
        m2.setFont(new Font("Ralway",Font.BOLD,14));
        m2.setBounds(450,390,150,30);
        m2.setBackground(new Color(222,255,228));
        m2.setForeground(Color.WHITE);
        add(m2);

        m3 = new JRadioButton("Other");
        m3.setFont(new Font("Ralway",Font.BOLD,14));
        m3.setBounds(600,390,100,30);
        m3.setBackground(new Color(222,255,228));
        m3.setForeground(Color.WHITE);
        add(m3);

        ButtonGroup buttonGroup2 = new ButtonGroup();
        buttonGroup2.add(m1);
        buttonGroup2.add(m2);
        buttonGroup2.add(m3);


        JLabel labeladress = new JLabel("Address  : ");
        labeladress.setFont(new Font("Railway",Font.BOLD,20));
        labeladress.setBounds(150,430,600,30);
       // labeladress.setForeground(Color.WHITE);
        add(labeladress);

        textad = new JTextField();
        textad.setFont(new Font("Ralway",Font.BOLD,14));
        textad.setBounds(300,430,400,30);
        add(textad);

        JLabel labelcity = new JLabel("City   : ");
        labelcity.setFont(new Font("Ralway",Font.BOLD,20));
        labelcity.setBounds(150,470,600,30);
       // labelcity.setForeground(Color.WHITE);
        add(labelcity);

        textcity = new JTextField();
        textcity.setFont(new Font("Ralway",Font.BOLD,14));
        textcity.setBounds(300,470,400,30);
        add(textcity);

        JLabel labelpincode = new JLabel("Pincode   : ");
        labelpincode.setFont(new Font("Ralway",Font.BOLD,20));
        labelpincode.setBounds(150,510,600,30);
      //  labelpincode.setForeground(Color.WHITE);
        add(labelpincode);

        textpin = new JTextField();
        textpin.setFont(new Font("Ralway",Font.BOLD,14));
        textpin.setBounds(300,510,400,30);
        add(textpin);

        JLabel labelstate = new JLabel("State   : ");
        labelstate.setFont(new Font("Ralway",Font.BOLD,20));
        labelstate.setBounds(150,550,600,30);
      //  labelstate.setForeground(Color.WHITE);
        add(labelstate);

        textstate = new JTextField();
        textstate.setFont(new Font("Ralway",Font.BOLD,14));
        textstate.setBounds(300,550,400,30);
        add(textstate);

        next = new JButton("Next");
        next.setFont(new Font("Ralway",Font.BOLD,14));
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.setBounds(450,600,80,30);
        next.addActionListener(this);
        add(next);

        /*ImageIcon image1 = new ImageIcon(ClassLoader.getSystemResource("Icon/back.png"));
        Image image2 = image1.getImage().getScaledInstance(1550,800,Image.SCALE_DEFAULT);
        ImageIcon image3 = new ImageIcon(image2);
        JLabel imagelabel = new JLabel(image3);
        imagelabel.setBounds(0,0,1550,800);
        add(imagelabel);*/

        setLayout(null);
        getContentPane().setBackground(new Color(222,255,228));
        setSize(850,800);
        setLocation(0,0);
        setUndecorated(true);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        String foname = first;
        String name = textname.getText();
        String fname = textfname.getText();
        String dob = ((JTextField)dateChooser.getDateEditor().getUiComponent()).getText();
        String gender = null;
        if(r1.isSelected())
        {
            gender = "Male";
        }else if(r2.isSelected())
        {
            gender = "Female";
        }

        String email = textemail.getText();
        String marital = null;
        if(m1.isSelected()){
            marital = "Married";
        }else if(m2.isSelected()){
            marital = "UnMarried";
        }else if(m3.isSelected()){
            marital = "Other";
        }

        String address = textad.getText();
        String city = textcity.getText();
        String pincode = textpin.getText();
        String state = textstate.getText();

        try{
            if(textname.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Fill all fields");
            }else{
                Con con1 = new Con();
                String q = "insert into signup values('"+foname+"','"+name+"','"+fname+"','"+dob+"','"+gender+"','"+email+"','"+marital+"','"+address+"','"+city+"','"+pincode+"','"+state+"')";
                con1.statement.executeUpdate(q);
                new Signup2(first);
                setVisible(false);
            }



        }catch(Exception E){
            E.printStackTrace();
        }





    }

    public static void main(String[] args) {
        new Signup();
    }
}
