package bank.managment.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Pin extends JFrame implements ActionListener {

    String pin;

    JButton b1,b2;
    JPasswordField p1,p2;

    Pin(String pin){

        super(" Pin Change ");

        this.pin = pin;

        JLabel l1 = new JLabel(" CHANGE YOUR PIN ");
        l1.setFont(new Font("Railway",Font.BOLD,16));
        l1.setBounds(420,180,400,35);
        l1.setForeground(Color.WHITE);
        add(l1);

        JLabel l2 = new JLabel(" NEW PIN : ");
        l2.setFont(new Font("Railway",Font.BOLD,14));
        l2.setBounds(420,220,200,35);
        l2.setForeground(Color.WHITE);
        add(l2);

        p1 = new JPasswordField();
        p1.setBounds(600,220,200,25);
        p1.setFont(new Font("Railway",Font.BOLD,16));
        p1.setBackground(new Color(65,125,128));
        p1.setForeground(Color.WHITE);
        add(p1);

        JLabel l3 = new JLabel(" RE-ENTER NEW PIN : ");
        l3.setFont(new Font("Railway",Font.BOLD,14));
        l3.setBounds(420,260,200,35);
        l3.setForeground(Color.WHITE);
        add(l3);

        p2 = new JPasswordField();
        p2.setBounds(600,260,200,25);
        p2.setFont(new Font("Railway",Font.BOLD,16));
        p2.setBackground(new Color(65,125,128));
        p2.setForeground(Color.WHITE);
        add(p2);


        b1 = new JButton(" CHANGE ");
        b1.setBounds(700,340,150,35);
        b1.setBackground(new Color(65,125,128));
        b1.setForeground(Color.WHITE);
        b1.addActionListener(this);
        add(b1);

        b2 = new JButton(" BACK ");
        b2.setBounds(700,390,150,35);
        b2.setBackground(new Color(65,125,128));
        b2.setForeground(Color.WHITE);
        b2.addActionListener(this);
        add(b2);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icon/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1550,830,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0,1550,780);
        add(image);

        setSize(1550,830);
        setLayout(null);
        setLocation(0,0);
        setUndecorated(true);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        try{

            String pin1 = p1.getText();
            String pin2 = p1.getText();

            if(!pin1.equals(pin2)){
                JOptionPane.showMessageDialog(null," Enter Pin Dose Not Matched ");
                return;
            }
            if(e.getSource()==b1){
                if(p1.getText().equals("")){
                    JOptionPane.showMessageDialog(null," Enter New Pin ");
                    return;

                }
                if(p2.getText().equals("")){
                    JOptionPane.showMessageDialog(null," Re-Enter New Pin ");
                    return;
                }

                Con con = new Con();
                String q1 = "update bank set pin = '"+pin1+"' where pin = '"+pin+"'";
                String q2 = "update login set pin = '"+pin1+"' where pin = '"+pin+"'";
                String q3 = "update signup3 set pin = '"+pin1+"' where pin = '"+pin+"'";

                con.statement.executeUpdate(q1);
                con.statement.executeUpdate(q2);
                con.statement.executeUpdate(q3);

                JOptionPane.showMessageDialog(null," Pin Change Succesfully ");
                setVisible(false);
                new main_class(pin);
            }else if(e.getSource()==b2){
                new main_class(pin);
                setVisible(false);
            }

        }catch(Exception E){
            E.printStackTrace();
        }

    }

    public static void main(String[] args) {

        new Pin("");


    }
}
